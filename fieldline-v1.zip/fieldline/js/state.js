export const S = { view: 'overview', cleanup: null, pending: null, gesture: { on: false, engine: null, stream: null, last: null, hold: 0 }, stopRecording: null, sw: 'unknown', sensitivity: 0.5 };
export const VIEWS = [
  ['overview', 'Command Overview'], ['evidence', 'Evidence Vault'], ['signal', 'Signal Intelligence'], ['incidents', 'Incident Management'],
  ['sop', 'SOP Workbench'], ['translate', 'Translation Centre'], ['gesture', 'Gesture Controls'], ['training', 'Training Simulator'],
  ['security', 'Security Centre'], ['settings', 'System Settings']
];
